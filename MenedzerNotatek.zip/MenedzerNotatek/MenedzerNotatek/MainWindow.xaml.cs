using System.IO;
using System.Text;
using System.Windows;
using System.Windows.Media.Imaging;
using Microsoft.Win32;

namespace MenedzerNotatek;

public partial class MainWindow : Window
{
    public MainWindow()
    {
        InitializeComponent();
        Loaded += MainWindow_Loaded;
    }

    private void MainWindow_Loaded(object sender, RoutedEventArgs e)
    {
        string folderDanych = Path.Combine(AppContext.BaseDirectory, "Dane");
        string plikTekstowy = Path.Combine(folderDanych, "start.txt");
        string plikObrazu = Path.Combine(folderDanych, "domyslny.png");
        int zaladowanePliki = 0;
        try
        {
            if (File.Exists(plikTekstowy))
            {
                txtNotatka.Text = File.ReadAllText(plikTekstowy, Encoding.UTF8);
                zaladowanePliki++;
            }
        }
        catch (Exception ex)
        {
            PokazBlad("Nie udało się wczytać notatki początkowej.", ex);
        }
        try
        {
            if (File.Exists(plikObrazu))
            {
                imgPodglad.Source = WczytajObraz(plikObrazu);
                zaladowanePliki++;
            }
        }
        catch (Exception ex)
        {
            PokazBlad("Nie udało się wczytać obrazu początkowego.", ex);
        }
        lblStatus.Text = zaladowanePliki == 2
            ? "Załadowano pliki początkowe"
            : $"Załadowano {zaladowanePliki} z 2 plików początkowych — sprawdź folder Dane.";
    }

    private void BtnOtworzTekst_Click(object sender, RoutedEventArgs e)
    {
        var dialog = new OpenFileDialog
        {
            Title = "Wybierz plik notatki",
            Filter = "Pliki tekstowe (*.txt)|*.txt|Wszystkie pliki (*.*)|*.*"
        };
        if (dialog.ShowDialog(this) != true)
            return;
        try
        {
            txtNotatka.Text = File.ReadAllText(dialog.FileName, Encoding.UTF8);
            lblStatus.Text = $"Otwarto plik: {Path.GetFileName(dialog.FileName)}";
        }
        catch (Exception ex)
        {
            PokazBlad("Nie udało się otworzyć notatki.", ex);
        }
    }

    private void BtnZapiszTekst_Click(object sender, RoutedEventArgs e)
    {
        var dialog = new SaveFileDialog
        {
            Title = "Zapisz notatkę",
            DefaultExt = "txt",
            FileName = "notatka.txt",
            Filter = "Pliki tekstowe (*.txt)|*.txt",
            AddExtension = true,
            OverwritePrompt = true
        };
        if (dialog.ShowDialog(this) != true)
            return;
        try
        {
            File.WriteAllText(dialog.FileName, txtNotatka.Text, Encoding.UTF8);
            lblStatus.Text = $"Zapisano plik: {Path.GetFileName(dialog.FileName)}";
            MessageBox.Show(this, "Notatka została zapisana.", "Zapis zakończony",
                MessageBoxButton.OK, MessageBoxImage.Information);
        }
        catch (Exception ex)
        {
            PokazBlad("Nie udało się zapisać notatki.", ex);
        }
    }

    private void BtnWybierzObraz_Click(object sender, RoutedEventArgs e)
    {
        var dialog = new OpenFileDialog
        {
            Title = "Wybierz zdjęcie",
            Filter = "Pliki graficzne (*.png;*.jpg;*.jpeg)|*.png;*.jpg;*.jpeg"
        };
        if (dialog.ShowDialog(this) != true)
            return;
        try
        {
            imgPodglad.Source = WczytajObraz(dialog.FileName);
            lblStatus.Text = $"Wybrano obraz: {dialog.FileName}";
        }
        catch (Exception ex)
        {
            PokazBlad("Nie udało się wczytać obrazu.", ex);
        }
    }

    private static BitmapImage WczytajObraz(string sciezka)
    {
        var obraz = new BitmapImage();
        obraz.BeginInit();
        obraz.CacheOption = BitmapCacheOption.OnLoad;
        obraz.CreateOptions = BitmapCreateOptions.IgnoreImageCache;
        obraz.UriSource = new Uri(sciezka, UriKind.Absolute);
        obraz.EndInit();
        obraz.Freeze();
        return obraz;
    }

    private void PokazBlad(string komunikat, Exception ex)
    {
        lblStatus.Text = komunikat;
        MessageBox.Show(this, $"{komunikat}\n\n{ex.Message}", "Błąd",
            MessageBoxButton.OK, MessageBoxImage.Error);
    }
}
